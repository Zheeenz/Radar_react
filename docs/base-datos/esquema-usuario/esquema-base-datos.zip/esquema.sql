CREATE TABLE usuarios (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  nombre TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  "contraseña" TEXT NOT NULL,
  fecha_registro TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE comercios (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  nombre TEXT NOT NULL,
  direccion TEXT NOT NULL,
  telefono TEXT,
  email TEXT UNIQUE NOT NULL
);

CREATE TABLE planes (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  nombre TEXT NOT NULL,
  descripcion TEXT,
  precio NUMERIC(10, 2) NOT NULL
);

CREATE TABLE productos (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  nombre TEXT NOT NULL,
  descripcion TEXT,
  precio NUMERIC(10, 2) NOT NULL,
  comercio_id BIGINT REFERENCES comercios(id)
);

CREATE TABLE inventarios (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  producto_id BIGINT REFERENCES productos(id),
  cantidad INT NOT NULL
);

CREATE TABLE recetas (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  nombre TEXT NOT NULL,
  instrucciones TEXT
);

CREATE TABLE ingrediente_recetas (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  receta_id BIGINT REFERENCES recetas(id),
  producto_id BIGINT REFERENCES productos(id),
  cantidad NUMERIC(10, 2) NOT NULL
);

CREATE TABLE carritos (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  usuario_id BIGINT REFERENCES usuarios(id),
  fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE detalle_carritos (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  carrito_id BIGINT REFERENCES carritos(id),
  producto_id BIGINT REFERENCES productos(id),
  cantidad INT NOT NULL
);

CREATE TABLE favoritos (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  usuario_id BIGINT REFERENCES usuarios(id),
  producto_id BIGINT REFERENCES productos(id)
);

CREATE TABLE notificaciones (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  usuario_id BIGINT REFERENCES usuarios(id),
  mensaje TEXT NOT NULL,
  fecha TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE preferencia_usuario (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  usuario_id BIGINT REFERENCES usuarios(id),
  tipo_comida TEXT NOT NULL,
  nivel_preferencia INT CHECK (nivel_preferencia BETWEEN 1 AND 5)
);

ALTER TABLE usuarios ADD COLUMN plan_id BIGINT REFERENCES planes(id);
